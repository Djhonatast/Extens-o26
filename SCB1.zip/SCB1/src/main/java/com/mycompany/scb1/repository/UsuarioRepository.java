
package com.mycompany.scb1.repository;
import com.mycompany.scb1.domain.Usuario;
import java.sql.SQLException;

public interface UsuarioRepository {
    Usuario buscarPorMatricula(int matricula) throws SQLException;
    void atualizarTotalEmprestimos(int matricula, int novoTotal) throws SQLException;
    void inserir(Usuario usuario) throws SQLException;
    
}
