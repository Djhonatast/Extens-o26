
package com.mycompany.scb1.repository;
import com.mycompany.scb1.domain.Livro;
import java.sql.SQLException;
import java.util.List;

public interface LivroRepository {
    void inserir(Livro livro) throws SQLException;
    void atualizar(Livro livro) throws SQLException;
    void deletar(int id) throws SQLException;
    Livro buscarPorId(int id) throws SQLException;
    Livro buscarPorTitulo(String titulo) throws SQLException;
    List<Livro> buscarTodos() throws SQLException;
}
