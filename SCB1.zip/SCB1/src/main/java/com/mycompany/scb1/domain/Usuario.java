
package com.mycompany.scb1.domain;
public class Usuario {
    private Integer matricula;
    private String nome;
    private int totalEmprestimosAtivos;

    public Usuario() {}

    public Usuario(Integer matricula, String nome, int totalEmprestimosAtivos) {
        this.matricula = matricula;
        this.nome = nome;
        this.totalEmprestimosAtivos = totalEmprestimosAtivos;
    }

    public Integer getMatricula() { return matricula; }
    public void setMatricula(Integer matricula) { this.matricula = matricula; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public int getTotalEmprestimosAtivos() { return totalEmprestimosAtivos; }
    public void setTotalEmprestimosAtivos(int totalEmprestimosAtivos) { this.totalEmprestimosAtivos = totalEmprestimosAtivos; }
}
