/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.scb1.repository;
import com.mycompany.scb1.domain.Livro;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LivroRepositoryImpl implements LivroRepository {

    @Override
    public void inserir(Livro livro) throws SQLException {
        String sql = "INSERT INTO livro (titulo, autor, categoria, status) VALUES (?, ?, ?, ?)";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, livro.getTitulo());
            ps.setString(2, livro.getAutor());
            ps.setString(3, livro.getCategoria());
            ps.setString(4, livro.getStatus());
            ps.executeUpdate();
        }
    }

    @Override
    public void atualizar(Livro livro) throws SQLException {
        String sql = "UPDATE livro SET titulo = ?, autor = ?, categoria = ?, status = ? WHERE id = ?";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, livro.getTitulo());
            ps.setString(2, livro.getAutor());
            ps.setString(3, livro.getCategoria());
            ps.setString(4, livro.getStatus());
            ps.setInt(5, livro.getId());
            ps.executeUpdate();
        }
    }

    @Override
    public void deletar(int id) throws SQLException {
        String sql = "DELETE FROM livro WHERE id = ?";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    @Override
    public Livro buscarPorId(int id) throws SQLException {
        String sql = "SELECT * FROM livro WHERE id = ?";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Livro(rs.getInt("id"), rs.getString("titulo"), 
                                     rs.getString("autor"), rs.getString("categoria"), rs.getString("status"));
                }
            }
        }
        return null;
    }

    @Override
    public Livro buscarPorTitulo(String titulo) throws SQLException {
        String sql = "SELECT * FROM livro WHERE LOWER(titulo) = LOWER(?)";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, titulo);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Livro(rs.getInt("id"), rs.getString("titulo"), 
                                     rs.getString("autor"), rs.getString("categoria"), rs.getString("status"));
                }
            }
        }
        return null;
    }

    @Override
    public List<Livro> buscarTodos() throws SQLException {
        List<Livro> lista = new ArrayList<>();
        String sql = "SELECT * FROM livro";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(new Livro(rs.getInt("id"), rs.getString("titulo"), 
                          rs.getString("autor"), rs.getString("categoria"), rs.getString("status")));
            }
        }
        return lista;
    }
}
