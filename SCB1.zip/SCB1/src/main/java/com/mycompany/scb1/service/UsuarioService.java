
package com.mycompany.scb1.service;
import com.mycompany.scb1.domain.Usuario;
import com.mycompany.scb1.exception.ValidacaoException;
import com.mycompany.scb1.repository.UsuarioRepository;
import com.mycompany.scb1.repository.UsuarioRepositoryImpl;
import java.sql.SQLException;

public class UsuarioService {
    private UsuarioRepository repository = new UsuarioRepositoryImpl();

    public void cadastrarUsuario(int matricula, String nome) throws ValidacaoException, SQLException {
        if (nome == null || nome.trim().isEmpty() || matricula <= 0) {
            throw new ValidacaoException("Erro: Matrícula inválida ou Nome não preenchido.");
        }
        
        if (repository.buscarPorMatricula(matricula) != null) {
            throw new ValidacaoException("Erro: Usuário com esta matrícula já existe.");
        }

        Usuario usuario = new Usuario(matricula, nome, 0);
        repository.inserir(usuario);
    }
}
