
package com.mycompany.scb1.domain;
public class Livro {
    private Integer id;
    private String titulo;
    private String autor;
    private String categoria;
    private String status; // "Disponível" ou "Emprestado"

    public Livro() {}

    public Livro(Integer id, String titulo, String autor, String categoria, String status) {
        this.id = id;
        this.titulo = titulo;
        this.autor = autor;
        this.categoria = categoria;
        this.status = status;
    }

    // Getters e Setters
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }
    public String getAutor() { return autor; }
    public void setAutor(String autor) { this.autor = autor; }
    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}