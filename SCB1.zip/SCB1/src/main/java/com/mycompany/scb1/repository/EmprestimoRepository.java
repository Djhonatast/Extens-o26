
package com.mycompany.scb1.repository;
import com.mycompany.scb1.domain.Emprestimo;
import java.sql.SQLException;

public interface EmprestimoRepository {
    void inserir(Emprestimo emprestimo) throws SQLException;
    Emprestimo buscarAtivoPorLivro(int idLivro) throws SQLException;
    void deletar(int idEmprestimo) throws SQLException; 
}
