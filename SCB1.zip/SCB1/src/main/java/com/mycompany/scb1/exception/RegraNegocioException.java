
package com.mycompany.scb1.exception;
public class RegraNegocioException extends Exception {
    public RegraNegocioException(String mensagem) {
        super(mensagem);
    }
}
