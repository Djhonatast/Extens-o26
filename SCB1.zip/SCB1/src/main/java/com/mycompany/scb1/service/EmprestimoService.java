/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.scb1.service;
import com.mycompany.scb1.domain.Emprestimo;
import com.mycompany.scb1.domain.Livro;
import com.mycompany.scb1.domain.Usuario;
import com.mycompany.scb1.exception.RegraNegocioException;
import com.mycompany.scb1.repository.*;
import java.sql.SQLException;
import java.time.LocalDate;

public class EmprestimoService {
    
    private LivroRepository livroRepo = new LivroRepositoryImpl();
    
    private UsuarioRepository usuarioRepo = new UsuarioRepositoryImpl();
    private EmprestimoRepository empRepo = new EmprestimoRepositoryImpl();

    public void realizarEmprestimo(int matricula, int idLivro) throws RegraNegocioException, SQLException {
        Usuario usuario = usuarioRepo.buscarPorMatricula(matricula);
        if (usuario == null) throw new RegraNegocioException("Erro: Usuário não encontrado. [MSG-03]");

        if (usuario.getTotalEmprestimosAtivos() >= 5) {
            throw new RegraNegocioException("Erro: Usuário atingiu o limite de 5 empréstimos simultâneos. [RN-03]");
        }

        Livro livro = livroRepo.buscarPorId(idLivro);
        if (livro == null) throw new RegraNegocioException("Erro: Livro não encontrado.");

        if (!"Disponível".equals(livro.getStatus())) {
            throw new RegraNegocioException("Erro: Livro indisponível para empréstimo. [MSG-02]");
        }

        livro.setStatus("Emprestado");
        livroRepo.atualizar(livro);

        usuario.setTotalEmprestimosAtivos(usuario.getTotalEmprestimosAtivos() + 1);
        usuarioRepo.atualizarTotalEmprestimos(matricula, usuario.getTotalEmprestimosAtivos());

        Emprestimo emp = new Emprestimo();
        emp.setUsuario(usuario);
        emp.setLivro(livro);
        emp.setDataEmprestimo(LocalDate.now());
        emp.setDataPrevistaDevolucao(LocalDate.now().plusDays(7));
        
        empRepo.inserir(emp); 
    }
    
}
