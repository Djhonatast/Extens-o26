/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.scb1;
import com.mycompany.scb1.exception.RegraNegocioException;
import com.mycompany.scb1.exception.ValidacaoException;
import com.mycompany.scb1.service.EmprestimoService;
import com.mycompany.scb1.service.LivroService;
import com.mycompany.scb1.service.UsuarioService;
import java.sql.SQLException;
import java.util.Scanner;

public class SCB1 {
    public static void main(String[] args) {
        UsuarioService usuarioService = new UsuarioService();
        LivroService livroService = new LivroService();
        EmprestimoService emprestimoService = new EmprestimoService();
        
        System.setProperty("file.encoding", "UTF-8");
    try {
        System.setOut(new java.io.PrintStream(System.out, true, "UTF-8"));
    } catch (java.io.UnsupportedEncodingException e) {
    }
        
        System.setProperty("file.encoding", "UTF-8");
        Scanner scanner = new Scanner(System.in, "UTF-8");
        int opcao = -1;

        do {
            System.out.println("   SISTEMA DE BIBLIOTECA - SCB ");
            System.out.println("1 - Cadastrar Usuário");
            System.out.println("2 - Cadastrar Novo Livro");
            System.out.println("3 - Realizar Empréstimo");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opção: ");
            
            try {
                opcao = scanner.nextInt();
                scanner.nextLine(); 

                switch (opcao) {
                    case 1:
                        System.out.println("\n--- CADASTRAR USUÁRIO ---");
                        System.out.print("Digite a Matrícula: ");
                        int matricula = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Digite o Nome do Usuário: ");
                        String nome = scanner.nextLine();
                        
                        usuarioService.cadastrarUsuario(matricula, nome);
                        System.out.println(">> Sucesso: Usuário gravado no Banco de Dados!");
                        break;

                    case 2:
                        System.out.println("\n--- CADASTRAR LIVRO ---");
                        System.out.print("Título do Livro: ");
                        String titulo = scanner.nextLine();
                        System.out.print("Autor: ");
                        String autor = scanner.nextLine();
                        System.out.print("Categoria: ");
                        String categoria = scanner.nextLine();
                        
                        livroService.cadastrarLivro(titulo, autor, categoria);
                        System.out.println(">> Sucesso: Livro gravado no Banco de Dados!");
                        break;

                    case 3:
                        System.out.println("\n--- REALIZAR EMPRÉSTIMO ---");
                        System.out.print("Digite a Matrícula do Usuário: ");
                        int matEmp = scanner.nextInt();
                        System.out.print("Digite o ID do Livro: ");
                        int idLivroEmp = scanner.nextInt();
                        
                        emprestimoService.realizarEmprestimo(matEmp, idLivroEmp);
                        System.out.println(">> Sucesso: Empréstimo registrado e status do livro atualizado!");
                        break;

                    case 0:
                        System.out.println("Encerrando a aplicação...");
                        break;
                        
                    default:
                        System.out.println("Opção inválida! Tente novamente.");
                }
            } catch (ValidacaoException | RegraNegocioException e) {
                System.out.println("\n[AVISO DO SISTEMA]: " + e.getMessage());
            } catch (SQLException e) {
                System.out.println("\n[ERRO DE BANCO]: Erro ao comunicar com o PostgreSQL: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("\n[ERRO INESPERADO]: Entrada inválida. Tente novamente.");
                scanner.nextLine();
            }
            
        } while (opcao != 0);
        
        scanner.close();
    }
}