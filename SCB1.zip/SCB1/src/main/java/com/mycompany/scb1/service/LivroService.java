
package com.mycompany.scb1.service;
import com.mycompany.scb1.domain.Livro;
import com.mycompany.scb1.exception.ValidacaoException;
import com.mycompany.scb1.repository.LivroRepository;
import com.mycompany.scb1.repository.LivroRepositoryImpl;
import java.sql.SQLException;

public class LivroService {
    private LivroRepository repository = new LivroRepositoryImpl();

    public void cadastrarLivro(String titulo, String autor, String categoria) throws ValidacaoException, SQLException {
        if (titulo == null || titulo.trim().isEmpty() || autor == null || autor.trim().isEmpty() || categoria == null || categoria.trim().isEmpty()) {
            throw new ValidacaoException("Erro: Campo obrigatório não preenchido. [MSG-010]");
        }

        if (repository.buscarPorTitulo(titulo) != null) {
            throw new ValidacaoException("Erro: Livro já cadastrado no sistema. [MSG-011]");
        }

        Livro livro = new Livro(null, titulo, autor, categoria, "Disponível");
        repository.inserir(livro);
    }
}
