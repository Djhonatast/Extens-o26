/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.scb1.repository;
import com.mycompany.scb1.domain.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsuarioRepositoryImpl implements UsuarioRepository {

    
    @Override
public void inserir(Usuario usuario) throws SQLException {
    String sql = "INSERT INTO usuario (matricula, nome, total_emprestimos) VALUES (?, ?, ?)";
    try (Connection conn = ConnectionFactory.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setInt(1, usuario.getMatricula());
        ps.setString(2, usuario.getNome());
        ps.setInt(3, usuario.getTotalEmprestimosAtivos());
        ps.executeUpdate();
    }
}
    @Override
    public Usuario buscarPorMatricula(int matricula) throws SQLException {
        String sql = "SELECT * FROM usuario WHERE matricula = ?";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, matricula);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Usuario(rs.getInt("matricula"), rs.getString("nome"), rs.getInt("total_emprestimos"));
                }
            }
        }
        return null; 
    }

    @Override
    public void atualizarTotalEmprestimos(int matricula, int novoTotal) throws SQLException {
        String sql = "UPDATE usuario SET total_emprestimos = ? WHERE matricula = ?";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, novoTotal);
            ps.setInt(2, matricula);
            ps.executeUpdate();
        }
    }
}
