/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.scb1.repository;
import com.mycompany.scb1.domain.Emprestimo;
import com.mycompany.scb1.domain.Livro;
import com.mycompany.scb1.domain.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EmprestimoRepositoryImpl implements EmprestimoRepository {

    @Override
    public void inserir(Emprestimo emprestimo) throws SQLException { 
        String sql = "INSERT INTO emprestimo (matricula_usuario, id_livro, data_emprestimo, data_prevista) VALUES (?, ?, ?, ?)";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, emprestimo.getUsuario().getMatricula());
            ps.setInt(2, emprestimo.getLivro().getId());
            ps.setDate(3, java.sql.Date.valueOf(emprestimo.getDataEmprestimo()));
            ps.setDate(4, java.sql.Date.valueOf(emprestimo.getDataPrevistaDevolucao()));
            ps.executeUpdate();
        }
    }

    @Override
    public Emprestimo buscarAtivoPorLivro(int idLivro) throws SQLException {
        String sql = "SELECT * FROM emprestimo WHERE id_livro = ?";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idLivro);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Emprestimo emp = new Emprestimo();
                    emp.setId(rs.getInt("id"));
                    
                   
                    Usuario u = new Usuario();
                    u.setMatricula(rs.getInt("matricula_usuario"));
                    emp.setUsuario(u);
                    
                    Livro l = new Livro();
                    l.setId(rs.getInt("id_livro"));
                    emp.setLivro(l);
                    
                    return emp;
                }
            }
        }
        return null;
    }

    @Override
    public void deletar(int idEmprestimo) throws SQLException {
        String sql = "DELETE FROM emprestimo WHERE id = ?";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idEmprestimo);
            ps.executeUpdate();
        }
    }
}
